/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/19 10:25:46 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/20 16:38:57 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_bsq.h"

t_list				*ft_define_sq_prop(char *str)
{
	t_list			*sq_props;
	int				length;
	int				start;
	long long int	res;

	res = 0;
	start = 0;
	length = ft_strlength(str) - 1;
	(*sq_props).width = 0;
	sq_props = (t_list *)malloc(sizeof(t_list) + 100);
	(*sq_props).fline_index = length;
	(*sq_props).plain_char = str[length - 1];
	(*sq_props).obstacle = str[length - 2];
	(*sq_props).valid_char = str[length - 3];
	while (start < length - 3)
	{
		res = res * 10 + str[start] - '0';
		start++;
	}
	(*sq_props).height = res;
	return (sq_props);
}

void				ft_init(t_data *data)
{
	data->j = 0;
	data->hauteur = 0;
}

int					read_val_execute(t_list *sq_props, t_data *data)
{
	data->str = ft_evaluate_first_line(data->file_name, &(data->fd));
	sq_props = ft_define_sq_prop(data->str);
	if (open(data->file_name, O_RDWR) < 0)
		return (1);
	data->hauteur = ft_open(sq_props, data->fd, &(data->j));
	if (data->hauteur == -1)
		return (1);
	sq_props->width = data->j;
	if (ft_val_height(data, sq_props) == 1)
		return (1);
	return (0);
}

int					main(int ac, char **av)
{
	t_list			*sq_props;
	t_coord			*coord;
	t_data			*data;
	int				i;

	if(!(data = (t_data *)malloc(sizeof(t_data) * 100)))
		return (0);
	if(!(coord = (t_coord *)malloc(sizeof(t_coord))))
		return(0);
	ft_init(data);
	if (ac == 1)
	{
		ft_create_file();
		data->file_name = "stdin_file";
		read_val_execute(sq_props, data);
	}
	i = 0;
	if (ac >= 2)
		while(i++ <= (ac - 2))
		{
			data->file_name = av[i];
			read_val_execute(sq_props, data);
		}
	return (0);
}
