/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   maps_validations.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/19 17:43:09 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/21 13:39:22 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_bsq.h"

int		ft_check(char c, t_list *info, int j, int *height)
{
	if (c != (*info).obstacle && c != (*info).valid_char && c != '\n')
		return (1);
	if (c == '\n')
	{
		(*height)++;
		if ((*info).width != j)
		{
			write(1, "Yo\n", 3);
			return (1);
		}
		(*info).width = 0;
	}
	if (c != '\n')
		(*info).width++;
	return (0);
}

int				ft_er(t_data *data, t_list *sq_props)
{
	if (data->hauteur != sq_props->height)
	{
		ft_error();
		return (1);
	}
	return (0);
}

int		ft_val_height(t_data *data, t_list *sq_props)
{
	if (data->hauteur != sq_props->height)
	{
		ft_error();
		return (1);
	}
	return (0);
}

void	ft_error(void)
{
	write(2, "map error\n", 10);
}
