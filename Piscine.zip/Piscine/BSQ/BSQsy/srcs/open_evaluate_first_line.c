/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validations.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/19 12:29:40 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/21 14:10:27 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_bsq.h"

char			*ft_evaluate_first_line(char *str, int *fd)
{
	char		buf[1];
	char		*ret;
	int			length;
	int			first_line;

	length = 0;
	first_line = 1;
	*fd = open(str, O_RDWR);
	if ((ret = (char *)malloc(1)))
	{
		while ((read(*fd, buf, 1) != 0 && first_line == 1))
		{
			if (buf[0] == '\n')
				first_line = 0;
			ret = ft_remalloc(ret, length + 1);
			ret[length] = buf[0];
			length++;
		}
		ret[length] = '\0';
	}
	if (close(*fd) == -1)
		ft_putstr("close error ()");
	return (ret);
}

int				ft_open(t_list *sq_props, int fd, int *j)
{
	t_ok		*ok;

	ok = (t_ok *)malloc(sizeof(ok) + 40);
	ok->i = -1;
	*j = 0;
	ok->k = 0;
	ok->hauteur = 0;
	while (++(ok->i) <= (*sq_props).fline_index)
	{
		read(fd, ok->buf, 1);
		(ok->buf)[1] = '\0';
	}
	while ((read(fd, ok->buf, 1)))
	{
		if (ok->k < 3 && (ok->buf)[0] != '\n')
			(*j)++;
		if ((ok->buf)[0] == '\n')
			ok->k = 5;
		printf("%i", *j);
		printf("%c", (ok->buf)[0]);
		if (ft_check((ok->buf)[0], sq_props, *j, &(ok->hauteur)) == 1)
		{	
			write(1, "coco\n", 6);
			ft_error();
			return (-1);
		}
	}
	return (ok->hauteur);
}
