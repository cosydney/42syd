/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bsq.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/19 10:20:04 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/19 22:45:29 by qtrinh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_BSQ_H
# define FT_BSQ_H
# include <unistd.h>
# include <stdlib.h>

typedef enum	e_boolean
{
	TRUE, FALSE
}				t_boolean;
typedef struct	s_square
{
	int		x;
	int		y;
	int		size;
}				t_square;
char			*ft_remalloc(char *str, int size);
char			*ft_read(void);
void			ft_putchar(char c);
void			ft_putnbr(int nb);
int				ft_strlen(char *str);
void			ft_putstr(char *str);
int				ft_atoi(char *str);
void			ft_switchchar(char *empty, char full);
void			ft_print_map(char **map);
t_boolean		validate_map(char **map);
t_square		ft_create_sqr(int x, int y, int size);

#endif
