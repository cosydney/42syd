/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qtrinh <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/05 11:53:04 by qtrinh            #+#    #+#             */
/*   Updated: 2016/09/12 23:13:55 by qtrinh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <math.h>

char	*ft_remove_space(char *str)
{
	while ((*str == ' ') || (*str == '\t') || (*str == '+') || (*str == '0'))
		str++;
	return (str);
}

int		ft_convert(char *str, int index)
{
	int nb;

	nb = 0;
	while (str[index] >= '0' && str[index] <= '9')
	{
		nb *= 10;
		nb += (str[index] - '0');
		index++;
	}
	return (nb);
}

int		ft_atoi(char *str)
{
	str = ft_remove_space(str);
	if (str[0] - '0' <= 9 && str[0] - '0' >= 0)
		return (ft_convert(str, 0));
	else if (str[0] == 45)
		return (-(ft_convert(str, 1)));
	else
		return (0);
}
