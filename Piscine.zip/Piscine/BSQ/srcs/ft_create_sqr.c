/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_create_sqr.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qtrinh <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/19 22:34:50 by qtrinh            #+#    #+#             */
/*   Updated: 2016/09/21 01:43:12 by qtrinh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_bsq.h"

t_square	ft_create_sqr(int x, int y, int size)
{
	t_square	sqr;

	sqr.x = x;
	sqr.y = y;
	sqr.size = size;
	return (sqr);
}
