/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_file_putstr.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qtrinh <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/15 16:53:35 by qtrinh            #+#    #+#             */
/*   Updated: 2016/09/15 18:29:05 by qtrinh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "../includes/ft_header.h"

void	ft_file_putstr(int fd, char *str)
{
	write(fd, str, ft_strlen(str));
}
