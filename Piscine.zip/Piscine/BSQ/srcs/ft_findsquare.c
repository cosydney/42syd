/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_findsquare.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qtrinh <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/19 11:33:26 by qtrinh            #+#    #+#             */
/*   Updated: 2016/09/21 13:20:40 by qtrinh           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/ft_bsq.h"
#include <string.h>
#include <stdio.h>

t_boolean	validate_coor(int x, int y, char **map, char empty)
{
	if (map[y][x] == empty)
		return (TRUE);
	return (FALSE);
}

t_boolean	validate_map(char **map)
{
	int l;
	int i;
	int j;

	l = 1;
	if (map[1][0] == '\0' || map[0][0] == '\0')
		return (FALSE);
	else
	{
		j = ft_strlen(map[0]) - 2;
		while (map[l])
		{
			i = 0;
			if (ft_strlen(map[l]) != ft_strlen(map[1]))
				return (FALSE);
			while (map[l][i] && map[l][i] != '\n')
			{
				if (map[l][i] != map[0][j] && map[l][i] != map[0][j - 1] && map[l][i] != map[0][j - 2])
					return (FALSE);
				i++;
			}
			l++;
		}
		if (l != ft_atoi(map[0]) + 1)
			return (FALSE);
	}
	return (TRUE);
}

t_boolean	validate_sqr(t_square sqr, char emp, char **map)
{
	int		*cur;

	cur = (int *)malloc(sizeof(int) * 2);
	cur[0] = sqr.x;
	cur[1] = sqr.y;
	if (cur[1] > ft_atoi(map[0]) - sqr.size + 1 ||
		cur[0] > ft_strlen(map[1]) - 2 - sqr.size + 1)
		return (FALSE);
	while (cur[1] < sqr.y + sqr.size)
	{
		cur[0] = sqr.x;
		while (cur[0] < sqr.x + sqr.size)
		{
			if (map[cur[1]][cur[0]] != emp)
				return (FALSE);
			cur[0]++;
		}
		cur[1]++;
	}
	return (TRUE);
}

char		**draw_sqr(char **map, t_square sqr)
{
	int		*cur;

	cur = (int *)malloc(sizeof(int) * 2);
	cur[1] = sqr.y;
	if (sqr.size > 0)
	{
		while (cur[1] < sqr.y + sqr.size && cur[1] <= ft_atoi(map[0]))
		{
			cur[0] = sqr.x;
			while (cur[0] < sqr.x + sqr.size && cur[0] <= ft_strlen(map[1]) - 2)
			{
				ft_switchchar(&map[cur[1]][cur[0]], 'x');
				cur[0]++;
			}
			cur[1]++;
		}
	}
	return (map);
}

t_square	sqr_cmp(t_square sqr1, t_square sqr2)
{
	if (sqr1.size > sqr2.size)
		return (sqr1);
	else if (sqr1.size < sqr2.size)
		return (sqr2);
	else
	{
		if (sqr1.y == sqr2.y && sqr1.x < sqr2.x)
			return (sqr1);
		else if (sqr1.y == sqr2.y && sqr1.x > sqr2.x)
			return (sqr2);
		else if (sqr1.y > sqr2.y)
			return (sqr2);
		else
			return (sqr1);
	}
	return (sqr1);
}

t_square	biggest_sqr(t_square sqr, char emp, char **map)
{
	if (validate_sqr(sqr, emp, map) == TRUE)
	{
		sqr.size++;
		return (biggest_sqr(sqr, emp, map));
	}
	else
	{
		sqr.size--;
		return (sqr);
	}
}

char		**find_sqr(char **map)
{
	int			x;
	int			y;
	t_square	sqr;
	t_square	biggest;
	char		**temp;

	x = 0;
	y = 1;
	biggest = ft_create_sqr(x, y, 0);
	while (y <= ft_atoi(map[0]))
	{
		x = 0;
		while (x <= ft_strlen(map[1]) - 2)
		{
			sqr = ft_create_sqr(x, y, 0);
			biggest = sqr_cmp(biggest, biggest_sqr(sqr, '.', map));
			x++;
		}
		y++;
	}
	map = draw_sqr(map, biggest);
	return (map);
}

int			main(void)
{
	char		**map;
	t_square	sqr;

	map = (char **)malloc(sizeof(char *) * 11);
	map[0] = (char *)malloc(sizeof(char) * 7);
	strncpy(map[0], "10.ox\n", 7);
	map[1] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[1], ".......................o..o...\n", 32);
	map[2] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[2], "............o.o.o..o..........\n", 32);
	map[3] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[3], "..o...........................\n", 32);
	map[4] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[4], "o....o..o...o.................\n", 32);
	map[5] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[5], "...o..o................o......\n", 32);
	map[6] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[6], "..........o.oo.........o.....o\n", 32);
	map[7] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[7], ".oo.o...............o......o..\n", 32);
	map[8] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[8], ".oo.............o.............\n", 32);
	map[9] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[9], ".........o.......o....o.......\n", 32);
	map[10] = (char *)malloc(sizeof(char) * 32);
	strncpy(map[10], ".o.o...o.....o.o...o..........\n", 32);
	map = find_sqr(map);
	ft_print_map(map);
	return (0);
}
