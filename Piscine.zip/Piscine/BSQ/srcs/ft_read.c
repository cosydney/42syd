/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_read.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/19 10:19:08 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/19 10:19:33 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_bsq.h"

char	*ft_remalloc(char *str, int size)
{
	char	*dst;
	int		i;

	i = 0;
	if (!(dst = (char *)malloc(sizeof(char) * size + 1)))
		return (NULL);
	while (str[i])
	{
		dst[i] = str[i];
		i++;
	}
	dst[i + 1] = '\0';
	free(str);
	return (dst);
}

char	*ft_read(void)
{
	char	buf[1];
	char	*str;
	int		length;

	length = 0;
	if ((str = (char *)malloc(1)))
	{
		while ((read(0, buf, 1) != 0))
		{
			str = ft_remalloc(str, length + 1);
			str[length] = buf[0];
			length++;
		}
		str[length] = '\0';
		return (str);
	}
	else
		return (NULL);
}
