/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/19 10:25:46 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/19 12:09:21 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_bsq.h"
#include <stdio.h>

int		main(int ac, char **ar)
{
	char	*str;
	
	str = NULL;
	if (ac < 2)
		str = ft_read();
	else 
		//write(1, '\n', 1);
	ar = NULL;
	printf("%s\n", str);

	return(0);
}
