#!/bin/sh
ldapwhoami | cut -c 4-
