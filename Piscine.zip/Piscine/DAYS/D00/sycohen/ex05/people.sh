#!/bin/sh
ldapsearch -xLLL uid='z*' cn | grep -E "(cn)" | sort -bdfr  | cut -c 5-
