#!/bin/bash 
ifconfig | grep -E 'ether' | cut -d " " -f 2
