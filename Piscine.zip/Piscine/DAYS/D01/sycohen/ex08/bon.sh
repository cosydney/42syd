#!/bin/bash
ldapsearch -xLLL sn='*bon*' cn | grep -E "(cn)" | wc -l | tr -d '  '
