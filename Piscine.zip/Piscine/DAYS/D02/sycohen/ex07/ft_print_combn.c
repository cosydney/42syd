/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_combn.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/01 00:12:10 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/01 00:31:10 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include<unistd.h>

void ft_putchar(char c)
{
	write(1, &c, 1);
}

void ft_print_char(a, b)
{
	ft_putchar(a);
	ft_putchar(b);
	ft_putchar(',');
	ft_putchar(' ');
}

void ft_print_combn(void)
{
	char a; 
	char b;

	a = '0';
	while (a <= '9')
	{
		b = '0';
		while (b <= '9')
		{
		ft_print_char(a, b);
		b++;
		}
	a++;
	}
}


int main()
{
	ft_print_combn();	
	return(0);
}
