// find . | norminette -R CheckForbiddenSourceHeader

#include "./ex00/ft_ft.c"
#include "./ex01/ft_ultimate_ft.c"
#include "./ex02/ft_swap.c"
#include "./ex03/ft_div_mod.c"
#include "./ex04/ft_ultimate_div_mod.c"
#include "./ex05/ft_putstr.c"
#include "./ex06/ft_strlen.c"
#include "./ex07/ft_strrev.c"
#include "./ex08/ft_atoi.c"

#include <stdio.h>
#include <unistd.h>

void ft_putchar(char c)
{
	write(1, &c,1);
}


int main()
{
	int reponse;
	printf("####################------------------Ex00 ft ft---------------#################\n");
	reponse = 38;
	ft_ft(&reponse);
	printf("Return : %d (return expected 42)\n", reponse);


	printf("####################------------------Ex01 ft_ultimate_ft---------------#################\n\n");

	printf("####################------------------Ex02 ft_ultimate_swap---------------#################\n");
	int a, b, *ptra, *ptrb;
	ptra = &a;
	ptrb = &b;
	a = 10;
	b = 300;
	ft_swap(ptra, ptrb);
	printf("initial a= 10, b = 300. Swap a %i b %i\n\n\n", *ptra, *ptrb );


	printf("####################------------------Ex03 ft_div_mod---------------#################\n");
	int divise, diviseur, *mod, *resultat, y, z;
	divise = 42;
	diviseur = 10;
	resultat = &y;
	mod = &z;

	ft_div_mod(diviseur, divise, resultat, mod );

	printf("On divise %d par %d\n", divise, diviseur);
	printf("Le resultat est de %d, et le modulo est de %d\n\n\n", *resultat, *mod);

	printf("####################------------------Ex04 ft_ultimate_div_mod---------------#################\n");

	printf("on divise %d / %d ", divise, diviseur);
	ft_ultimate_div_mod(&divise, &diviseur);
	printf("Le resultat est de %d et le modulo est de %d\n\n\n\n", divise, diviseur);


	printf("####################------------------Ex05 ft_putstr---------------#################\n");
	char hello[100] = "Bonjour monde";
	printf("Hello world en francais %si\n\n\n", hello);	
	ft_putstr(hello);
	printf("\n\n\n");

	printf("####################------------------Ex06 ft_str_len---------------#################\n");

	reponse = ft_strlen(hello);
	printf(" Nombre de caracteres -> %d (reponse attendu c'est 13 caracteres) \n\n\n\n", reponse);


	printf("####################------------------Ex07 ft_strrev---------------#################\n");

	ft_strrev(hello);
	printf("String a l'envers: -> %s (reponse attendu: ednom ruojnoB)\n\n\n\n", hello);

	printf("####################------------------Ex08 atoi---------------#################\n");

	char tableau[100] = "-889";
	ft_atoi(&tableau[0]);
	printf("Atoimisator : %s\n resultat attendu (-889)", tableau);

}
