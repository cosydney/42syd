gcc main.c -Wall -Wextra -Werror 
