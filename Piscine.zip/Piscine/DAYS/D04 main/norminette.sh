find . | norminette -R CheckForbiddenSourceHeader
