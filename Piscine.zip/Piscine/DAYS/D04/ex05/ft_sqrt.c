/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/02 14:13:59 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/02 14:43:13 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	int racine;

	racine = 0;
	if (nb <= 0)
		return (0);
	while (racine * racine < nb)
		racine++;
	if (nb == racine * racine)
		return (racine);
	return (0);
}
