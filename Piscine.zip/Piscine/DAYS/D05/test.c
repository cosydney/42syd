#include <stdlib.h>

char    *ft_create_single_string(char **argv, char *str)
{
	int    size;
	int    i;
	int    j;

	j = 0;
	i = 1;
	size = 0;
	while (argv[i])
	{
		j = 0;
		while (argv[i][j])
		{
			str[size] = argv[i][j];
			j++;
			size++;
		}
		str[size++] = '\n';
		i++;
	}
	str[--size] = '\0';
	return (str);
}

char    *ft_concat_params(int argc, char **argv)
{
	char    *str;
	int    size;
	int    i;
	int    j;

	i = 1;
	size = 0;
	while (argv[i])
	{
		j = 0;
		while (argv[i][j])
		{
			j++;
		}
		size += j;
		i++;
	}
	str = (char*)malloc(sizeof(char) * size + argc - 1);
	str = ft_create_single_string(argv, str);
	return (str);
}
