gcc -Wextra -Wall -Werror -c ft_*.c
ar rc libft.a ft_*.o
rm *.o
ranlib libft.a
