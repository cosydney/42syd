/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_concat_params.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/07 17:21:43 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/07 20:52:46 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_concat_string(char **argv, char *str)
{
	int		size;
	int		i;
	int		j;

	j = 0;
	i = 1;
	size = 0;
	while (argv[i])
	{
		j = 0;
		while (argv[i][j])
		{
			str[size] = argv[i][j];
			j++;
			size++;
		}
		str[size++] = '\n';
		i++;
	}
	str[--size] = '\0';
	return (str);
}

char	*ft_concat_params(int argc, char **argv)
{
	char	*str;
	int		size;
	int		i;
	int		j;

	i = 1;
	size = 0;
	while (argv[i])
	{
		j = 0;
		while (argv[i][j])
		{
			j++;
		}
		size = size + j;
		i++;
	}
	str = (char*)malloc(sizeof(char) * size + argc - 1);
	str = ft_concat_string(argv, str);
	return (str);
}
