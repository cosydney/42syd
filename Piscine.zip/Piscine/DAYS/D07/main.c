/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/07 14:40:38 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/07 16:38:54 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

#include "./ex00/ft_strdup.c"
#include "./ex01/ft_range.c"

int main(void)
{
	int i;
	int *tab;


	printf("#-EX00- FT_RANGE_#\n");
	char coucou[9] = "coucou";
	printf("%p\n", &coucou);
	printf("%s\n", ft_strdup(coucou));
	printf("%p\n\n", ft_strdup(coucou));	

	printf("#-EX01- FT_RANGE_#\n");
	i = 0;
	tab = ft_range(8, 200);
	while (i < (200 - 8))
	{
		printf("%d ", tab[i++]);
	}
	/*
	   printf("#-EX00- FT_RANGE_#\n");
	   printf("\n\n");
	   printf("#-EX00- FT_RANGE_#\n");
	   printf("\n\n");
	   printf("#-EX00- FT_RANGE_#\n");
	   printf("\n\n");
	   printf("#-EX00- FT_RANGE_#\n");
	   printf("\n\n");
	   printf("#-EX00- FT_RANGE_#\n");
	   printf("\n\n");
	   */
	return (0);

}

