#include <stdio.h>


int		ft_ultimate_range(int **range, int min, int max);

int		main()
{

	int s;
	int i = 0;
	int *tab[78];

	s = ft_ultimate_range(tab, 5000, 5030);
	printf("%d", s);

	return (0);
}
