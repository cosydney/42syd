/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/07 18:39:19 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/08 13:58:32 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "./ex03/ft_concat_params.c"

int main(int argc, char **argv)
{
	printf("%s \n", ft_concat_params(argc, argv));
	return (0);
}
