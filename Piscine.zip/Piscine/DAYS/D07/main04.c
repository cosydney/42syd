/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main04.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/08 17:08:49 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/08 20:57:28 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./ex04/ft_split_whitespaces.c"
#include <stdio.h>
#include <stdio.h>
int main(void)
{
	char **tab = ft_split_whitespaces("Hello this is me ");
	printf("%s", tab[0]);
	printf("%s", tab[1]);
	printf("%s", tab[2]);
	printf("%s", tab[3]);
	printf("%s", tab[4]);

}
