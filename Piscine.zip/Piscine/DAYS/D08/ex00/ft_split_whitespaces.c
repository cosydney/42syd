/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ad_whitespace.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/09 15:41:52 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/09 22:38:52 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	**ft_alloc_table(char **table, char *str)
{
	int		i;
	int		counts;

	i = 0;
	counts = 0;
	while (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		i++;
	while (str[i] != '\0')
	{
		i++;
		if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		{
			counts++;
			while (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
				i++;
		}
	}
	if (str[i - 1] == ' ' || str[i - 1] == '\n' || str[i - 1] == '\t')
		counts++;
	table = (char**)malloc(sizeof(*table) * (counts + 1));
	table[counts] = 0x0;
	return (table);
}

char	**ft_alloc_str(char **table, char *str)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	j = 0;
	k = 0;
	table = ft_alloc_table(table, str);
	while (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		i++;
	while (str[i] != '\0')
	{
		i++;
		if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t' || str[i] == '\0')
		{
			table[j] = (char*)malloc(sizeof(**table) * (k + 1));
			j++;
			k = 0;
			while (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
				i++;
		}
		k++;
	}
	return (table);
}

char	**ft_put_table(char **table, char *str)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	j = 0;
	k = 0;
	table = ft_alloc_str(table, str);
	while (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		i++;
	while (str[i] != '\0')
	{
		table[j][k] = str[i];
		i++;
		k++;
		if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t' || str[i] == '\0')
		{
			table[j][k] = '\0';
			j++;
			k = 0;
			while (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
				i++;
		}
	}
	return (table);
}

char	**ft_split_whitespaces(char *str)
{
	char **table;

	table = NULL;
	table = ft_put_table(table, str);
	return (table);
}
