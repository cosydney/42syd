/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/09 00:15:30 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/09 10:59:10 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_takes_place(int hour)
{
	printf("THE FOLLOWING TAKES PLACE BETWEEN ");
	if (hour == 0)
		printf("12.00 A.M. AND 1.00 A.M.\n");
	if (hour < 12 && hour > 0)
		printf("%i.00 A.M. AND %i A.M.\n", hour, hour + 1);
	if (hour == 12)
		printf("12.00 P.M. AND 1.00 P.M.\n");
	if (hour > 12)
		printf("%i.00 P.M AND %i P.M.\n", hour, hour + 1);
}
