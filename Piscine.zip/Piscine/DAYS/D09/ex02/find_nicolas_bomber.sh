cat annuaire | tr '[:upper:]' '[:lower:]' |grep -e "nicolas" | grep -e "bomber" | head -1 | cut -f 3
