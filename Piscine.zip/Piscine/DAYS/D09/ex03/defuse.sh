stat bomb.txt | cut -f 2 -d ' ' | awk '{ print $1 -= 1 }'
