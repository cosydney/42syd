/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_button.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/09 13:35:00 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/09 13:42:59 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_button(int i, int j, int k)
{
	if (j == k && i == j)
		return (i);
	if (i < j)
	{
		if (j < k)
			return (j);
		else
		{
			if (k < i)
				return (i);
			else
				return (k);
		}
	}
	if (j < k)
	{
		if (i < k)
			return (i);
		else
			return (k);
	}
	else
		return (j);
	return (j);
}
