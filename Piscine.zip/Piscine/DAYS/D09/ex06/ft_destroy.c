/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_destroy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/09 13:56:07 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/09 13:57:48 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

void    ft_destroy(char ***factory)
{
	int i;

	i = 0;
	while (factory)
	{
		free((*factory)[i]);
		i++;
	}
	free(**factory);
	***factory = NULL;
}
