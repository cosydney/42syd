/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_collatz_conjecture.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/09 14:02:47 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/09 14:03:02 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int    ft_collatz_conjecture(unsigned int base)
{
	if (base > 1)
	{
		if (base % 2 == 0)
			return (1 + ft_collatz_conjecture(base / 2));
		else
			return (1 + ft_collatz_conjecture(3 * base + 1));
	}
	return (0);
}
