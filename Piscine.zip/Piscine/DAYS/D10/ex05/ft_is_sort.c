/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/12 13:29:31 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/12 15:20:28 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int i;
	int j;

	i = 0;
	j = 0;
	while ((f(tab[i], tab[i + 1]) == -1
				|| f(tab[i], tab[i + 1]) == 0) && i < length - 1)
		i++;
	while ((f(tab[j], tab[j + 1]) == 1
				|| f(tab[j], tab[j + 1]) == 0) && j < length - 1)
		j++;
	if (i == length - 1 || j == length - 1)
		return (1);
	return (0);
}
