/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_header.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/12 15:41:08 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/12 17:44:01 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_HEADER_H
# define FT_HEADER_H

# include <unistd.h>

typedef struct	s_ops
{
	char	op;
	void	(*f)(int, int);
}				t_ops;
void			ft_sum(int a, int b);
void			ft_substract(int a, int b);
void			ft_divide(int a, int b);
void			ft_multiply(int a, int b);
void			ft_modulo(int a, int b);
int				ft_atoi(char *str);
void			ft_putchar(char c);
void			ft_putstr(char *str);
void			ft_putnbr(int nb);
int				ft_strlen(char *str);
#endif
