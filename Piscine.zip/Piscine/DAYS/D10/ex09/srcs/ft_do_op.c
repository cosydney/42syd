/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_do_op.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/12 16:14:37 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/12 17:52:18 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

void	ft_sum(int a, int b)
{
	ft_putnbr(a + b);
}

void	ft_substract(int a, int b)
{
	ft_putnbr(a - b);
}

void	ft_divide(int a, int b)
{
	if (b != 0)
		ft_putnbr(a / b);
	else
		ft_putstr("Stop : division by zero");
}

void	ft_multiply(int a, int b)
{
	ft_putnbr(a * b);
}

void	ft_modulo(int a, int b)
{
	if (b != 0)
		ft_putnbr(a % b);
	else
		ft_putstr("Stop : modulo by zero");
}
