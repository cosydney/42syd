/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/12 15:32:18 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/12 17:52:02 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

void	ft_init_ops(t_ops *s_my_ops)
{
	s_my_ops[0].op = '+';
	s_my_ops[0].f = &ft_sum;
	s_my_ops[1].op = '-';
	s_my_ops[1].f = &ft_substract;
	s_my_ops[2].op = '/';
	s_my_ops[2].f = &ft_divide;
	s_my_ops[3].op = '*';
	s_my_ops[3].f = &ft_multiply;
	s_my_ops[4].op = '%';
	s_my_ops[4].f = &ft_modulo;
}

int		main(int argc, char **argv)
{
	int		i;
	int		error;
	t_ops	s_my_ops[5];

	i = -1;
	if (argc == 4 && ft_strlen(argv[2]) == 1)
	{
		ft_init_ops(s_my_ops);
		while (i++ < 5)
			if (s_my_ops[i].op == argv[2][0])
			{
				s_my_ops[i].f(ft_atoi(argv[1]), ft_atoi(argv[3]));
				error = 0;
			}
		if (error)
			ft_putstr("0");
		ft_putchar('\n');
	}
	return (0);
}
