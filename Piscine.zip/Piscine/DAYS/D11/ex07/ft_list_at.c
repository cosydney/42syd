/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_at.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/13 17:38:16 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/13 19:03:57 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_list.h"

t_list	*ft_list_at(t_list *begin_list, unsigned int nbr)
{
	unsigned int i;

	i = 1;
	if (!begin_list)
		return (NULL);
	while (begin_list)
	{
		if (i == nbr)
			return (begin_list);
		begin_list = (begin_list)->next;
		i++;
	}
	return (NULL);
}
