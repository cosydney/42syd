/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_foreach_if.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/13 22:03:07 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/14 21:16:20 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void ft_list_foreach_if(t_list *begin_list, void (*f)(void *), void *data_ref, int (*cmp)())
{
	t_list *list;

	list = begin_list;
	if (list)
	{
		while (list->next != NULL)
		{
			if ((*cmp)(list->data, data_ref) == 0)
				(*f)(list->data);
			list = list->next;
		}
	}
}
