/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_find.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/13 22:03:07 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/14 21:11:41 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void ft_list_find(t_list *begin_list, void *data_ref, int (*cmp)())
{
	t_list *list;

	list = begin_list;
	if (list)
	{
		while (list->next != NULL)
		{
			if ((*cmp)(list->data, data_ref) == 0)
				return (list);
			list = list->next;
		}
		return (NULL);
	}
}
