/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_display_file.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/14 13:06:49 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/14 16:17:51 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <fcntl.h>
#include <unistd.h>

int	main(int ac, char **ar)
{
	char	buf;
	int		fd;

	if (ac > 2)
		write(1, "Too many arguments.\n", 20);
	if (ac < 2)
		write(1, "File name missing.\n", 19);
	if (ac == 2)
	{
		fd = open(ar[1], O_RDONLY);
		while (read(fd, &buf, 1) != 0)
			write(1, &buf, 1);
	}
}
