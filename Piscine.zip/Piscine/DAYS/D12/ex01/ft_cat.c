/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cat.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/14 16:08:39 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/14 20:57:32 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>

void	ft_putstr(int fd, char *str)
{
	int i;

	i = -1;
	while (str[i++])
		write(fd, &str[i], 1);
}

void    ft_display(char *str)
{
	char    buf[2];
	int        fd;
	int        ret;

	fd = open(str, O_RDONLY);
	if (fd == -1)
	{
		ft_putstr(2, "cat: ");
		ft_putstr(2, str);
		ft_putstr(2, ": No such file or directory\n");
	}
	while ((ret = read(fd, buf, 1)))
		ft_putstr(1, buf);
	fd = close(fd);
}

int        main(int argc, char **argv)
{
	int i;
	char buf;

	i = 1;
	if (argc < 2 || argv[i][0] == '-')
	{
		while(read(0, &buf, 1))
			write(1, &buf, 1);	
	}
	while (i < argc)
		ft_display(argv[i++]);
	return (0);
}
