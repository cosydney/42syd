nclude "ft_my_header.h"

int ft_errno_err(char *str, int index)
{
	int i;
	int j;

	i = 0;
	j = 0;
	write(2, "cat: ", 5);
	while (str[i])
	{
		write(2, &str[i], 1);
		i++;
	}
	write(2, ": ", 2);
	while (g_error_tab[index - 1].descr[j])
	{
		write(2, &g_error_tab[index - 1].descr[j], 1);
		j++;
	}
	write(2, "\n", 1);
	return (1);
}

void ft_putstr(char *str)
{
	int i;

	i = 0;
	while (str[i])
	{
		ft_putchar(str[i]);
		i++;
	}
}

int ft_read_file(char *ar)
{
	char buf[2];
	int fd;
	int ret;

	errno = 0;
	fd = open(ar, O_RDWR);
	if (errno)
		return (ft_errno_err(ar, errno));
	if (fd == -1)
		return (ft_open_error());
	while ((ret = read(fd, buf, 1)))
	{
		buf[ret] = '\0';
		ft_putstr(buf);
	}
	if (close(fd) == -1)
		return (ft_close_error());
	return (0);
}

void ft_read_entry(void)
{
	char buf[2];
	int ret;

	if ((ret = read(0, buf, 1)))
	{
		buf[ret] = '\0';
		write(1, buf, 1);
		while ((ret = read(0, buf, 1)))
		{
			buf[ret] = '\0';
			write(1, buf, 1);
		}
	}
	else
	{
		ft_repeat_entry();
	}
}

int main(int ac, char **ar)
{
	int i;

	i = 1;
	while (ar[i])
	{
		if ((ar[i][0] == '-' && ar[i][1] == 0) || ac == 1)
		{
			ft_repeat_entry();
			i++;
		}
		else if (ar[i][0] == '-' && ar[i][1] != '\0')
			return (1);
		else
		{
			ft_read_file(ar[i]);
			i++;
		}
	}
	if (ac == 1)
		ft_read_entry();
	return (0);
}
