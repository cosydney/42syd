#include <stdio.h>

char *ft_rot42(char *str);

int main()
{
	char str[] = "aAkKzZ";
	printf("%s", ft_rot42(str));
	return (0);
}
