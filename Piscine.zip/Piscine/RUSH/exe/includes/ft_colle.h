/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_colle.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcharbon <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/17 12:35:21 by lcharbon          #+#    #+#             */
/*   Updated: 2016/09/17 18:39:15 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_COLLE_H
# define FT_COLLE_H
#include <unistd.h>
#include <stdio.h>


void	ft_putchar(char c);
char	*colle00(int x, int y);
//char	*colle01(int x, int y);
//char	*colle02(int x, int y);
//char	*colle03(int x, int y);
//char	*colle04(int x, int y);
int		ft_atoi(char *str);

#endif
