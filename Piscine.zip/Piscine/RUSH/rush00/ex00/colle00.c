/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle00.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bbeldame <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/03 13:45:26 by bbeldame          #+#    #+#             */
/*   Updated: 2016/09/17 15:07:51 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

void	ft_putchar(char c);

char	*print_row(int width, char start, char center, char last, char *str)
{
	int i;

	i = 0;
	if (width >= 1)
		ft_putchar(start);
	while (i < (width - 2))
	{
		ft_putchar(center);
		i++;
	}
	if (width > 1)
		ft_putchar(last);
	ft_putchar('\n');
}

char	*colle(int x, int y)
{
	int i;
	char *str;
	int index;

	index = 0;
	str = (char * )malloc(sizeof(char) * (x + 1) * y + 1);
	i = 2;
	if (x > 0)
	{
		if (y > 0)
			print_row(x, 'o', '-', 'o', index, str);
		while (i < y)
		{
			print_row(x, '|', ' ', '|', index , str);
			i++;
		}
		if (y > 1)
			print_row(x, 'o', '-', 'o', index, str);
	}
	str[index] = '\0';
	return (str);
}
