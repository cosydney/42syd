/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle01.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bbeldame <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/03 13:45:33 by bbeldame          #+#    #+#             */
/*   Updated: 2016/09/03 20:29:41 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	print_row(int width, char start, char center, char last)
{
	int i;

	i = 0;
	if (width >= 1)
		ft_putchar(start);
	while (i < (width - 2))
	{
		ft_putchar(center);
		i++;
	}
	if (width > 1)
		ft_putchar(last);
	ft_putchar('\n');
}

void	colle(int x, int y)
{
	int i;

	i = 2;
	if (x > 0)
	{
		if (y > 0)
			print_row(x, '/', '*', '\\');
		while (i < y)
		{
			print_row(x, '*', ' ', '*');
			i++;
		}
		if (y > 1)
			print_row(x, '\\', '*', '/');
	}
}
