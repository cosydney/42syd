/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle03sydney.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/03 20:00:51 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/04 19:05:41 by pbouvier         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	print_row(int width, char start, char center, char last)
{
	int i;

	i = 0;
	if (width >= 1)
		ft_putchar(start);
	while (i < (width - 2))
	{
		ft_putchar(center);
		i++;
	}
	if (width > 1)
		ft_putchar(last);
	ft_putchar('\n');
}

void	colle(int x, int y)
{
	int i;

	i = 2;
	if (x > 0)
	{
		if (y > 0)
			print_row(x, 'A', 'B', 'C');
		while (i < y)
		{
			print_row(x, 'B', ' ', 'B');
			i++;
		}
		if (y > 1)
			print_row(x, 'A', 'B', 'C');
	}
}
