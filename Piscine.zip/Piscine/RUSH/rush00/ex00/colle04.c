/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/03 17:44:37 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/06 16:54:50 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	print_row(int width, char start, char center, char last)
{
	int i;

	if (width >= 1)
		ft_putchar(start);
	while (i < width - 2)
	{
		ft_putchar(center);
		i++;
	}
	if (width > 1)
		ft_putchar(last);
	ft_putchar('\n');
}

void	colle(int x, int y)
{
	int i;

	i = 2;

	if (x > 0)
	{
		if (y > 0)
			print_row(x, '0', '0', '0');
		while (i < y)
		{
			print_row(x, '0', ' ', '0');
			i++;
		}
		if (y > 1)
			print_row(x, '0', '0', '0');
	}
}
