/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bbeldame <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/03 13:44:47 by bbeldame          #+#    #+#             */
/*   Updated: 2016/09/17 15:27:09 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>

int		ft_atoi(char *str);
void	colle(int x, int y);

int		main(int ac, char **argv)
{
	colle(ft_atoi(argv[1]), ft_atoi(argv[2]));

	FILE *fp;
	char str[] = "This is Sydney writing a file and yes he is doing it braa";
	fp = fopen("colle00.txt", "w");
	fwrite(str, 1 , sizeof(str), fp);

	fclose(fp);

	return (0);
}
