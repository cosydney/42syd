/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/10 17:42:43 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/11 20:05:03 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# include <unistd.h>
# include <stdlib.h>

void	ft_print_results(int **tab);
void	ft_putchar(char c);
int		ft_check_input(int argc, char **argv);
int		ft_check_solvability(int **tab);
int		ft_check_for_doubles(int **tab);
int		**ft_replace_and_fill_tab(int	**tab, char	**argv);
int		ft_check_block(int i, int j, int nb, int **tab);
int		ft_check_line(int j, int nb, int **tab);
int		ft_check_column(int i, int nb, int **tab);
int		ft_compare_tabs(int **tab, int **rev);
int		ft_check_and_solve(int **tab, int **rev);
int		erreur(void);
int		ft_solve_grid(int **tab, int indice);
int		ft_solve_grid_rev(int **tab, int indice);

#endif
