/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_input.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/10 20:35:28 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/11 20:05:01 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_check_input(int argc, char **argv)
{
	int		i;
	int		j;
	int		k;

	i = 1;
	if (argc != 10)
		return (1);
	while (i < 10)
	{
		j = 0;
		k = 0;
		while (argv[i][j] != '\0')
		{
			if (argv[i][j] != '.' && (argv[i][j] < '1' || argv[i][j] > '9'))
				return (1);
			k++;
			j++;
		}
		if (k != 9)
			return (1);
		i++;
	}
	return (0);
}

int		ft_check_solvability(int **tab)
{
	int x;
	int y;
	int nbaboveo;

	y = 0;
	nbaboveo = 0;
	while (y < 9)
	{
		x = 0;
		while (x < 9)
		{
			if (tab[x][y] != 0)
				nbaboveo++;
			x++;
		}
		y++;
	}
	if (nbaboveo >= 17)
		return (0);
	return (1);
}

int		ft_check_for_doubles(int **tab)
{
	int i;
	int j;
	int nb;

	j = 0;
	while (j < 9)
	{
		i = 0;
		while (i < 9)
		{
			nb = 1;
			while (nb < 10)
			{
				if (ft_check_line(j, nb, tab) > 1
						|| ft_check_column(i, nb, tab) > 1
						|| ft_check_block(i, j, nb, tab) > 1)
					return (1);
				nb++;
			}
			i++;
		}
		j++;
	}
	return (0);
}

int		ft_check_and_solve(int **tab, int **rev)
{
	if (ft_check_for_doubles(tab) == 1 || ft_check_solvability(tab) == 1)
	{
		erreur();
		return (1);
	}
	if (!(ft_solve_grid(tab, 0)))
	{
		erreur();
		return (1);
	}
	if (!(ft_solve_grid_rev(rev, 81)))
	{
		erreur();
		return (1);
	}
	if (ft_compare_tabs(tab, rev))
		ft_print_results(tab);
	else
	{
		erreur();
		return (1);
	}
	return (0);
}
