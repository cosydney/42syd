/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_valid_grid.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/11 11:08:55 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/11 17:39:10 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int	ft_check_column(int i, int nb, int **tab)
{
	int k;
	int count;

	k = 0;
	count = 0;
	while (k < 9)
	{
		if (nb == tab[i][k])
			count++;
		k++;
	}
	return (count);
}

int	ft_check_line(int j, int nb, int **tab)
{
	int k;
	int count;

	k = 0;
	count = 0;
	while (k < 9)
	{
		if (nb == tab[k][j])
			count++;
		k++;
	}
	return (count);
}

int	ft_check_block(int i, int j, int nb, int **tab)
{
	int width;
	int height;
	int maxwidth;
	int maxheight;
	int count;

	count = 0;
	width = (i / 3) * 3;
	height = (j / 3) * 3;
	maxwidth = width + 3;
	maxheight = height + 3;
	while (height < maxheight)
	{
		width = (i / 3) * 3;
		while (width < maxwidth)
		{
			if (tab[width][height] == nb)
				count++;
			width++;
		}
		height++;
	}
	return (count);
}
