/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/10 15:45:41 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/11 20:04:07 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"
#include <ctype.h>

int		ft_solve_grid_rev(int **tab, int indice)
{
	int i;
	int j;
	int l;

	l = 9;
	i = indice % 9;
	j = indice / 9;
	if (indice == -1)
		return (1);
	if (tab[i][j] != 0)
		return (ft_solve_grid_rev(tab, indice - 1));
	while (l >= 1)
	{
		if (ft_check_column(i, l, tab) == 0 &&
				ft_check_line(j, l, tab) == 0 &&
				ft_check_block(i, j, l, tab) == 0)
		{
			tab[i][j] = l;
			if (ft_solve_grid_rev(tab, indice - 1))
				return (1);
		}
		l--;
	}
	tab[i][j] = 0;
	return (0);
}

int		ft_solve_grid(int **tab, int indice)
{
	int i;
	int j;
	int l;

	l = 1;
	i = indice % 9;
	j = indice / 9;
	if (indice == 81)
		return (1);
	if (tab[i][j] != 0)
		return (ft_solve_grid(tab, indice + 1));
	while (l <= 9)
	{
		if (ft_check_column(i, l, tab) == 0 &&
				ft_check_line(j, l, tab) == 0 &&
				ft_check_block(i, j, l, tab) == 0)
		{
			tab[i][j] = l;
			if (ft_solve_grid(tab, indice + 1))
				return (1);
		}
		l++;
	}
	tab[i][j] = 0;
	return (0);
}

int		**ft_replace_and_fill_tab(int **tab, char **argv)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < 9)
	{
		j = 0;
		while (j < 9)
		{
			if (argv[i + 1][j] == '.')
				tab[j][i] = 0;
			else
				tab[j][i] = argv[i + 1][j] - '0';
			j++;
		}
		i++;
	}
	return (tab);
}

int		erreur(void)
{
	write(1, "Erreur\n", 7);
	return (1);
}

int		main(int argc, char **argv)
{
	int		**tab;
	int		**rev;
	int		i;

	i = 0;
	if (ft_check_input(argc, argv) == 1)
		return (erreur() ? 0 : 1);
	if ((!(tab = (int**)malloc(9 * sizeof(int*))))
		|| (!(rev = (int**)malloc(9 * sizeof(int*)))))
		return (erreur() ? 0 : 1);
	while (i < 10)
		if ((!(tab[i] = (int*)malloc(10 * sizeof(int))))
				|| (!(rev[i++] = (int*)malloc(10 * sizeof(int)))))
			return (erreur() ? 0 : 1);
	tab = ft_replace_and_fill_tab(tab, argv);
	rev = ft_replace_and_fill_tab(rev, argv);
	if (ft_check_and_solve(tab, rev) == 1)
		return (0);
	return (0);
}
