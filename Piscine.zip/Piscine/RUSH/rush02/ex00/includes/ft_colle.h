/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_colle.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcharbon <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/17 12:35:21 by lcharbon          #+#    #+#             */
/*   Updated: 2016/09/18 18:53:04 by sycohen          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_COLLE_H
# define FT_COLLE_H
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>

void	ft_putchar(char c);
int		ft_strcmp(char *s1, char *s2);
char	*colle00(int x, int y);
char	*colle01(int x, int y);
char	*colle02(int x, int y);
char	*colle03(int x, int y);
char	*colle04(int x, int y);
int		ft_compare(int width, int height, char *str);
int		print_result(int x, int y, int colle, int u);
int		ft_count_column(char *str);
int		ft_count_line(char *str);
void	ft_putnbr(int nb);

#endif
