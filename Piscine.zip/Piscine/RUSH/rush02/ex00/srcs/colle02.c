/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   colle02.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/17 15:09:44 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/18 14:22:26 by lcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_colle.h"

int		ft_return_last_line_02(int width, char *str, int index)
{
	int		i;

	i = 1;
	str[index] = 'A';
	index++;
	while (i <= width - 2)
	{
		str[index] = 'B';
		i++;
		index++;
	}
	if (width > 1)
	{
		str[index] = 'A';
		index++;
		i++;
	}
	str[index] = '\n';
	return (index + 1);
}

int		ft_return_center_02(int width, char *str, int index)
{
	int		i;

	i = 1;
	str[index] = 'B';
	index++;
	while (i <= width - 2)
	{
		str[index] = ' ';
		i++;
		index++;
	}
	if (width > 1)
	{
		str[index] = 'B';
		index++;
		i++;
	}
	str[index] = '\n';
	return (index + 1);
}

int		ft_return_bottom_02(int width, char *str, int index)
{
	int		i;

	i = 1;
	str[index] = 'C';
	index++;
	while (i <= width - 2)
	{
		str[index] = 'B';
		i++;
		index++;
	}
	if (width > 1)
	{
		str[index] = 'C';
		index++;
		i++;
	}
	str[index] = '\n';
	return (index + 1);
}

char	*colle02(int x, int y)
{
	int		height;
	char	*str;
	int		index;

	index = 0;
	str = (char *)malloc(sizeof(char) * (x + 1) * y + 1);
	height = 1;
	if (x > 0)
	{
		if (y > 0)
			index = ft_return_last_line_02(x, str, 0);
		while (height < y - 1)
		{
			index = ft_return_center_02(x, str, index);
			height++;
		}
		if (y > 1)
			index = ft_return_bottom_02(x, str, index);
	}
	str[index] = '\0';
	return (str);
}
