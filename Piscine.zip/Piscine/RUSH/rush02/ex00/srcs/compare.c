/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   compare.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcharbon <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/18 10:36:28 by lcharbon          #+#    #+#             */
/*   Updated: 2016/09/18 14:50:59 by lcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_colle.h"

int		ft_compare(int width, int height, char *str)
{
	int u;

	u = 0;
	if (width == 0 || height == 0)
		write(1, "aucune", 6);
	else
	{
		if (ft_strcmp(colle00(width, height), str) == 0)
			print_result(width, height, 0, u++);
		if (ft_strcmp(colle01(width, height), str) == 0)
			print_result(width, height, 1, u++);
		if (ft_strcmp(colle02(width, height), str) == 0)
			print_result(width, height, 2, u++);
		if (ft_strcmp(colle03(width, height), str) == 0)
			print_result(width, height, 3, u++);
		if (ft_strcmp(colle04(width, height), str) == 0)
			print_result(width, height, 4, u++);
		if (u == 0)
			write(1, "aucune", 6);
	}
	ft_putchar('\n');
	return (0);
}
