/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sycohen <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/17 17:13:06 by sycohen           #+#    #+#             */
/*   Updated: 2016/09/18 14:19:13 by lcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_colle.h"

char	*ft_remalloc(char *str, int size)
{
	char	*dst;
	int		i;

	i = 0;
	if (!(dst = (char *)malloc(sizeof(char) * size + 1)))
		return (NULL);
	while (str[i])
	{
		dst[i] = str[i];
		i++;
	}
	dst[i + 1] = '\0';
	free(str);
	return (dst);
}

char	*ft_read(void)
{
	char	buf[1];
	char	*str;
	int		length;

	length = 0;
	if ((str = (char *)malloc(1)))
	{
		while ((read(0, buf, 1) != 0))
		{
			str = ft_remalloc(str, length + 1);
			str[length] = buf[0];
			length++;
		}
		str[length] = '\0';
		return (str);
	}
	else
		return (NULL);
}

int		main(int ac, char **ar)
{
	int		width;
	int		height;
	char	*str;

	str = ft_read();
	if (ar)
		;
	if (ac == 1)
	{
		height = ft_count_column(str);
		width = ft_count_line(str);
		ft_compare(height, width, str);
	}
	return (0);
}
