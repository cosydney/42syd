/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_result.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lcharbon <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/17 17:07:49 by lcharbon          #+#    #+#             */
/*   Updated: 2016/09/18 14:44:09 by lcharbon         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_colle.h"

int	print_result(int x, int y, int colle, int u)
{
	if (u > 0)
		write(1, " || ", 4);
	write(1, "[colle-0", 8);
	ft_putnbr(colle);
	write(1, "] [", 3);
	ft_putnbr(x);
	write(1, "] [", 3);
	ft_putnbr(y);
	write(1, "]", 1);
	return (u = 1);
	return (0);
}
